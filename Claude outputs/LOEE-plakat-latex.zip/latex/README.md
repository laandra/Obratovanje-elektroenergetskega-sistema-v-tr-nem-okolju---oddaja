# Plakat LOEE — LaTeX

Končna verzija plakata za Evolucija.AI 2026, format **70 × 100 cm pokončno**.

```
pdflatex plakat-loee.tex        # po potrebi dvakrat
```

Rezultat je enostranski PDF v točnih merah lista — datoteka za tiskarno.
Potrebni paketi so v standardni TeX Live: `geometry`, `graphicx`, `xcolor`,
`tikz`, `microtype`, `anyfontsize`, `helvet` in `babel-slovenian`
(v Linuxu paket `texlive-lang-european`).

## Datoteke

- `plakat-loee.tex` — vse na enem mestu: preambula in vsebina
- `slike/` — vektorske slike (PDF)
- `plakat-loee.pdf` — prevedena verzija

## Zgradba datoteke

Datoteka je razdeljena na oštevilčene odseke, ki jih najdete z iskanjem `[1]`,
`[2]` …:

1. **Paketi in mere** — velikost lista, robovi, širine stolpcev (`\levistolpec`,
   `\desnistolpec`, `\presledek`, `\razmikslik`)
2. **Barve** — celotna paleta
3. **Velikosti pisave** — vse velikosti (`\velNaslov`, `\velBesedilo` …)
4. **Pomožni ukazi** — `\sekcija`, `\prvasekcija`, `\podnapis`, `\objava`,
   `\locnica`
5. **Vsebina** — glava, naslov, levi (besedilni) in desni (slikovni) stolpec,
   objave, noga

## Pogosti posegi

**Naslov razdelka** — besedilo v `\sekcija{...}`; prvi razdelek v stolpcu
uporablja `\prvasekcija{...}` (nima razmika nad seboj).

**Dodajanje ali menjava slike** — v desnem stolpcu:

```latex
\vspace{\razmikslik}
\includegraphics[width=\linewidth]{slike/ime.pdf}
\podnapis{Slika 4}{Kaj slika pokaže.}
```

Na koncu desnega stolpca sta zakomentirani še dve možnosti: graf
`achievable-saving.pdf` in večpanelna slika poteka dneva `trace-day.pdf`
(z `trim` in `clip` za izrez posameznega panela).

**Če vsebina ne gre na eno stran** — zmanjšajte `\razmikslik`, razmik med
odstavki `\razmikodstavkov` ali velikost `\velBesedilo`. Ukaz `\vfill` med
stolpcema in objavami sam porine spodnji del na dno lista.

**Pisava** — privzeto Nimbus Sans (`helvet`). Za Barlow (kot v zaslonski
različici) namestite pisavo, prevajajte z `xelatex` ali `lualatex` in
odkomentirajte vrstici s `fontspec` v odseku [1].

**Format lista** — spremenite `paperwidth` in `paperheight` v `geometry`, nato
uskladite širine stolpcev tako, da je vsota `\levistolpec + \presledek +
\desnistolpec` enaka širini besedilnega bloka (širina lista minus oba robova).

## Za tisk

Slike so vektorske, zato ostanejo ostre pri kakršni koli velikosti. Barve so
definirane v RGB; tiskarna jih pretvori v CMYK, vrednosti so v odseku [2].
Logotipa UL FE in KCUI sta izvirni datoteki iz obeh celostnih grafičnih podob —
spreminjajte le `height`, širina se prilagodi sama.
